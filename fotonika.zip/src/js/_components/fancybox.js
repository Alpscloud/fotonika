// ========= F a n c y b o x ===========
$('[data-fancybox]').fancybox();
